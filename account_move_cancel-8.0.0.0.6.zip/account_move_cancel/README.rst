Account Move Cancel
===================

Cancels multiple invoices from a wizard and is called from other modules for direct
billing cancellations and cancel your withholding, withholding automatically validating
and maintaining the seat number that generated in its initial stage